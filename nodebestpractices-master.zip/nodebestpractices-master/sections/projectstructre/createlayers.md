# Layer your app, keep Express within its boundaries

<br/><br/>

 ### Separate component code into layers: web, services, and DAL

![alt text](https://github.com/i0natan/nodebestpractices/blob/master/assets/images/structurebycomponents.PNG "Separate component code into layers")

 <br/><br/>

### 1 min explainer: The downside of mixing layers

![alt text](https://github.com/i0natan/nodebestpractices/blob/master/assets/images/keepexpressinweb.gif "The downside of mixing layers")
